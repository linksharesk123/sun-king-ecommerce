package com.sunking.ecommerce.auth.service;

import com.sunking.ecommerce.auth.dto.UserDto;

public interface UserService {

    UserDto createUser(UserDto user);

}
