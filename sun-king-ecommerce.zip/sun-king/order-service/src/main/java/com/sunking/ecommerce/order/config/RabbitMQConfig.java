package com.sunking.ecommerce.order.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    // #TODO: Define queues, exchanges, and binding
}

