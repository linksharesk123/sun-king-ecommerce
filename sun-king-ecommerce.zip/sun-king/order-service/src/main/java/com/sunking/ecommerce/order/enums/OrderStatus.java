package com.sunking.ecommerce.order.enums;

public enum OrderStatus {
    PLACED, CANCELLED, SHIPPED, DELIVERED
}
